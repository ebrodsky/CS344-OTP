to compile, type
compileall

then just run the grading script.